package com.ama.agencybooks.model;

public enum SecurityLevel {
    TOP_SECRET,
    UNCLASSIFIED
}
